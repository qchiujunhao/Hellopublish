#!/bin/bash

echo "hello publish!"

python data/gen.py